package com.sundogsoftware.spark

import org.apache.spark._
import org.apache.spark.SparkContext._
import org.apache.log4j._

/** Count up how many of each star rating exists in the MovieLens 100K data set. */
object RatingsCounterScala {
 
  /** Our main function where the action happens */
  def main(args: Array[String]) {
   
      // Set the log level to only print errors
      Logger.getLogger("org").setLevel(Level.ERROR)
        
      // Create a SparkContext using every core of the local machine, named RatingsCounter
      val sc = new SparkContext("local[*]", "RatingsCounter")
   
      // Load up each line of the ratings data into an RDD
      val lines = sc.textFile("../ml-20m/ratings.csv")
    
      // Convert each line to a string, split it out by comma (",") , and extract the third field.
      // (The file format is userID, movieID, rating, timestamp)      
      
          
      val movieIds = lines.map(x => x.toString().split(",")(1))
      // Count up how many times each movie was rated
      val movie_id_rating_results = movieIds.countByValue();
      // Sort the resulting map of (movieId, count) tuples
      val sorted_movie_id_rating_results = movie_id_rating_results.toSeq.sortBy(_._1);
      println("");
      println("========================MOVIE_ID_OCCURENCE===============================");
      // Print each result on its own line.     
      sorted_movie_id_rating_results.foreach(println);
      
      /////////////////////////////////////////////////////////////////////////////////// 
      val ratings  = lines.map(x => x.toString().split(",")(2))    
      // Count up how many times each value (rating) occurs
      val rating_results = ratings.countByValue()    
      // Sort the resulting map of (rating, count) tuples
      val sorted_rating_results = rating_results.toSeq.sortBy(_._1)  
      println("");
      println("========================STARS_RATING_OCCURENCE===========================");
      // Print each result on its own line.
      sorted_rating_results.foreach(println)      
     

  }
}

package com.sundogsoftware.spark;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Map;
import java.util.TreeMap;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import scala.Tuple2;

/**
 * @author Steven Nguyen
 * email: steven.a.nguyen@gmail.com
 * Convert the original RatingCounter written in Scala to Java 8.
 * Date: 08/08/2017
 */
public class RatingsCounterJava {
	  
	  private static Map<String, Integer> ratingsMap;
	  
	  /** Our main function where the action happens 
	   * @throws IOException 
	   *
	   */	 
	  public static void  main(String args[]) throws IOException {
		  
		  /**
		  Op.timeOp(() -> {
			  try {
				  countRatingByMovieIdWithSpark();
			  }catch (IOException e) {
				  // TODO Auto-generated catch block
				  e.printStackTrace();
			  }
		  });
		  **/
		  
		  /**
		  Op.timeOp(() -> {
		  		try{
					countRatingByStarsWithSpark();
				}catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		  });
		  **/
		  
		  /**
		  Op.timeOp(() -> {
			  try{
				makeSmallDataFile();
			  }catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			  }
		  });
		  **/
	  }
	  
	  public static void countRatingByMovieIdWithSpark() throws IOException{
		  // Set the log level to only print errors
	      Logger.getLogger("org").setLevel(Level.ERROR);
	      ratingsMap = new TreeMap<String, Integer>();
		  /**
	       * The first thing a Spark program must do is to create a JavaSparkContext object,
	       * which tells Spark how to access a cluster.
	       */
		  SparkConf conf = new SparkConf()
				  				.setAppName("ratings-counter")
				  				.setMaster("local")
				  				.set("spark.cores.max", "4"); //4 cores CPU
		  
		  JavaSparkContext ctx  = new JavaSparkContext(conf);
		  // Convert each line to a string, split it out by comma (",") , and extract the related field.
	      // (The file format is userID, movieID, rating, timestamp)	  
		  //JavaRDD<String> lines = ctx.textFile(("../ml-20m/ratings.csv")).filter(s -> !s.contains("rating"));
		  JavaRDD<String> lines = ctx.textFile(("../ml-20m/ratings.csv"));
						  
		  JavaPairRDD<String, Integer> ratingOnePairs = lines.mapToPair(s -> new Tuple2<String, Integer>(s.split(",")[1], 1));
		  JavaPairRDD<String, Integer> results = ratingOnePairs.reduceByKey((i1, i2) -> i1 + i2);
		
		  //results.saveAsTextFile("../ml-20m/ratings-count.txt");
		  results.foreach(data ->{ratingsMap.put(data._1(),  data._2());});
		  
		  ctx.stop();	 
		  System.out.println(ratingsMap);	
	  }
	  
	  public static void countRatingByMovieId() throws IOException{
		  ratingsMap = new TreeMap<String, Integer>();
		  Path path = Paths.get("../ml-20m/ratings.csv");
		  Files.lines(path).map(s -> s.split(",")[1]).forEach(key->{
			  ratingsMap.merge(key, 1, Integer::sum);
		  });	
		  System.out.println(ratingsMap);	
	  }
	  
	  public static void countRatingByStarsWithSpark() throws IOException{
		  // Set the log level to only print errors
	      Logger.getLogger("org").setLevel(Level.ERROR);
	      ratingsMap = new TreeMap<String, Integer>();
		  /**
	       * The first thing a Spark program must do is to create a JavaSparkContext object,
	       * which tells Spark how to access a cluster.
	       */
		  SparkConf conf = new SparkConf()
				  				.setAppName("ratings-counter")
				  				.setMaster("local")
				  				.set("spark.cores.max", "1"); //4 cores CPU
		  
		  JavaSparkContext ctx  = new JavaSparkContext(conf);
		  // Convert each line to a string, split it out by comma (",") , and extract the related field.
	      // (The file format is userID, movieID, rating, timestamp)	  
		  // JavaRDD<String> lines = ctx.textFile(("../ml-20m/ratings.csv")).filter(s -> !s.contains("rating"));
		  JavaRDD<String> lines = ctx.textFile(("../ml-20m/ratings.csv"));
						  
		  JavaPairRDD<String, Integer> ratingOnePairs = lines.mapToPair(s -> new Tuple2<String, Integer>(s.split(",")[2], 1));
		  JavaPairRDD<String, Integer> results = ratingOnePairs.reduceByKey((i1, i2) -> i1 + i2);
		
		  //results.saveAsTextFile("../ml-20m/ratings-count.txt");
		  results.foreach(data ->{ratingsMap.put(data._1(),  data._2());});
		  
		  ctx.stop();	
		  System.out.println("");	 
		  System.out.println(ratingsMap);	
	  }
	  
	  public static void countRatingByStars() throws IOException{
		  ratingsMap = new TreeMap<String, Integer>();
		  Path path = Paths.get("../ml-20m/ratings.csv");
		  Files.lines(path).map(s -> s.split(",")[2]).forEach(key->{
			  ratingsMap.merge(key, 1, Integer::sum);
		  });
		  System.out.println("");	
		  System.out.println(ratingsMap);	
	  }
	  
	  public static void makeSmallDataFile() throws IOException{
		  Path inpath  = Paths.get("../ml-20m/ratings.csv");
		  Path outpath = Paths.get("../ml-20m/ratings-50.csv");
		  try(BufferedWriter bw = Files.newBufferedWriter(outpath, Charset.defaultCharset());
			  BufferedReader br = Files.newBufferedReader(inpath, Charset.defaultCharset())){
		  	  int count = 0;
		  	  String line = br.readLine();
		  	  while(count < 50 && line != null ){
		  		  bw.write(line);bw.newLine();
		  		  line = br.readLine();
		  		  count ++;
		  	  }
		  }
	  }
	  
}

package com.sundogsoftware.spark;

import java.io.IOException;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import scala.Tuple2;

/**
 * @author Steven Nguyen
 * email: steven.a.nguyen@gmail.com
 * Average rating by movie in Java 8.
 * Date: 08/08/2017
 */
public class AverageRatingsJava { //average star rating per movie. 
	
	  
	  /** Our main function where the action happens 
	   * @throws IOException 
	   *
	   */
	  public static void main(String[] args) throws IOException {
			Op.timeOp(() ->{
					try {
						averageRatingByMovieId();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			});
	  }
	
	  public static void averageRatingByMovieId() throws IOException{
		  // Set the log level to only print errors
	      Logger.getLogger("org").setLevel(Level.ERROR);
	     
		  /**
	       * The first thing a Spark program must do is to create a JavaSparkContext object,
	       * which tells Spark how to access a cluster.
	       */
		  SparkConf conf = new SparkConf()
				  				.setAppName("ratings-counter")
				  				.setMaster("local")
				  				.set("spark.cores.max", "4"); //4 cores CPU
		  
		  JavaSparkContext ctx  = new JavaSparkContext(conf);
		  // Convert each line to a string, split it out by comma (",") , and extract the related field.
	      // (The file format is userID, movieID, rating, timestamp)	  
		  JavaRDD<String> lines = ctx.textFile(("../ml-20m/ratings.csv")).filter(s -> !s.contains("userId"));
		  //JavaRDD<String> lines = ctx.textFile(("../ml-20m/ratings-50.csv")).filter(s -> !s.contains("userId"));
	      
		  // movieId, rating 
	      JavaPairRDD<Long, Double> ratings = lines.mapToPair(s -> new Tuple2<Long, Double>(Long.parseLong(s.split(",")[1]), Double.parseDouble(s.split(",")[2])));
	      
	      // movieId, (rating, 1)
	      JavaPairRDD<Long, Tuple2<Double, Integer>> mappedRatings = ratings.mapValues(x -> new Tuple2<Double, Integer>(x, 1));
		     		        
	      // movieId, (ratingsum, ratingcount)
	      JavaPairRDD<Long, Tuple2<Double, Integer>> reduced = mappedRatings.reduceByKey((x, y) -> new Tuple2<Double, Integer>(x._1 + y._1, x._2 + y._2));

	      // movieId, (ratingsum/ratingcount)
	      // reduced.mapToPair(x -> new Tuple2<>(x._1, (double)(x._2._1) / x._2._2)).saveAsTextFile(outputPath);        
	      JavaPairRDD<Long, Double> results = reduced.mapToPair(x -> new Tuple2<Long, Double>(x._1, (double) Math.round((x._2._1/x._2._2)*1000.0/1000.0)));

	      /**
	      reduced.foreach(data -> {
	        	System.out.println("("+data._1() + ",("+ data._2._1() + "," + data._2._2() +"))");
	      });
	      	      
	      results.sortByKey().foreach(data -> {
	        	System.out.println("("+data._1() + ","+ data._2() +")");
	      });
	      **/
	      
		  ctx.stop();	 

	  }
}
